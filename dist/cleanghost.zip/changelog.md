# Changelog

This changelog unfortunately starts at v1.2.7 since I didn't have the forethought to put one in beforehand.

**1.2.7 Changes:**

- Added bottom padding to `postfull-content` so that pages and posts don't look so jank.