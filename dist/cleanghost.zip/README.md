# Clean Ghost
Clean Ghost is a Ghost theme built on top of the default Casper theme for ghost. It takes a step back from the masonry grid that you get with the default Casper theme and focuses much more on the actual writing.

This theme does not include the functionality that casper does for images, in fact the reason this theme exists in the first place is to get rid of that and the grid. What you're left with is a list of posts on the homepage, a simple and clean navigation and posts without huge featured images at the top. The cover photos for authors is included, however.

# Demo
You can see the demo @ [my blog](https://blog.assassinskeeper.com).